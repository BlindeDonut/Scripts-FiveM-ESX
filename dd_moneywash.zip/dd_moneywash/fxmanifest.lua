fx_version 'cerulean'
games {'gta5'}
lua54 'yes'

author 'BlindeDonut'
version '1.0.0'

client_scripts {
    '@NativeUI/NativeUI.lua',
    'config.lua',
    'client.lua'
}

server_scripts {
    'server.lua'
}

escrow_ignore
{
	"config.lua",
	"client.lua"
}
