ESX = nil
Citizen.CreateThread(function()
    while ESX == nil do
        TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
        Citizen.Wait(0)
    end

end)


_menuPool = NativeUI.CreatePool()
local isNearMoneyWash = false

Citizen.CreateThread(function()
    while true do

        local playerCoords = GetEntityCoords(PlayerPedId())
        isNearMoneyWash = false

        for k, v in pairs(Config.Locations) do
            local dist = Vdist(playerCoords, v[1], v[2], v[3])
            if dist < 1.5 then
                isNearMoneyWash = true
            end
        end


        Citizen.Wait(350)
    end 
end)

Citizen.CreateThread(function()
    while true do

        _menuPool:ProcessMenus()

        if isNearMoneyWash then
            showInfobar('Drücke ~g~E~s~, um dein ~y~Geld ~r~zu waschen')
            if IsControlJustReleased(0, 38) then
                -- open Menu
                openMoneyWash()
            end
        elseif _menuPool:IsAnyMenuOpen() then 
            _menuPool:CloseAllMenus()
        end

        Citizen.Wait(1)
    end 
end)

function openMoneyWash()

    local moneyMenu = NativeUI.CreateMenu('Geld waschen', 'Wechselrate ~b~4:1')
    _menuPool:Add(moneyMenu)

    local washItem = NativeUI.CreateItem('Dein Geld waschen ...', '~b~')
    moneyMenu:AddItem(washItem)

    washItem.Activated = function(sender, index)

        local input = CreateDialog('Wie viel?')
        input = tonumber(input)
        if input ~= nil and input > 0 then
            -- Geld waschen...
            -- Betrag = input
            TriggerServerEvent('moneywash:wash', input)
        end

    end


    moneyMenu:Visible(true)
    _menuPool:MouseEdgeEnabled(false)

end

function CreateDialog(OnScreenDisplayTitle_shopmenu) --general OnScreenDisplay for KeyboardInput
    AddTextEntry(OnScreenDisplayTitle_shopmenu, OnScreenDisplayTitle_shopmenu)
    DisplayOnscreenKeyboard(1, OnScreenDisplayTitle_shopmenu, "", "", "", "", "", 32)
    while (UpdateOnscreenKeyboard() == 0) do
        DisableAllControlActions(0);
        Wait(0);
    end
    if (GetOnscreenKeyboardResult()) then
        local displayResult = GetOnscreenKeyboardResult()
        return displayResult
    end
end

function showInfobar(text)
    SetTextComponentFormat('STRING')
    AddTextComponentString(text)
    EndTextCommandDisplayHelp(0, 0, 1, -1)
end