Config = {}

Config.Locations = {
    {x, y, z}
}