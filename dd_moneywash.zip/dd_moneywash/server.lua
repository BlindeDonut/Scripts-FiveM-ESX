ESX = nil
TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

RegisterServerEvent('moneywash:wash')
AddEventHandler('moneywash:wash', function(amount)

    local xPlayer = ESX.GetPlayerFromId(source)
    
    if xPlayer.getAccount('black_money').money >= amount then
        xPlayer.removeAccountMoney('black_money', amount)
        xPlayer.addAccountMoney('money', math.floor(amount /2))
        xPlayer.showNotification('~r~' .. amount .. '$ Schwarzgeld ~s~wurden zu ~g~' .. math.floor(amount / 2) .. '$ ~s~umgewandelt.')
    else
        xPlayer.showNotification('~r~Nicht genügend Geld!')
    end
end)