# DD_moneywash #
Tank you for supporting me!

Come on my Discord if you need support
https://discord.gg/dW8zHxx9rJ

# Instalation #
- Download the resource
- Drop the script folder into your resources folder
- Make sure that the folder is named 'dd_moneywash'
- start the resource in your cfg and restart your Server

# Customize you like #
- You can set the Position in the Config.lua

# Other #
- The ratio is 2/1. Write me if you want to change that